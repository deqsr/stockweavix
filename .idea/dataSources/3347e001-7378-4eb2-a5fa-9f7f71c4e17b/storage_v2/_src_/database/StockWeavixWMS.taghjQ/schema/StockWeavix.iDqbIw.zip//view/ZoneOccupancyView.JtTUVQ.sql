CREATE VIEW Belteh.ZoneOccupancyView AS
WITH ZoneLocations AS (
    SELECT
        z.ZoneID,
        l.LocationID
    FROM Belteh.Zones z
    JOIN Belteh.ZoneRows zr ON zr.ZoneID = z.ZoneID
    JOIN Belteh.Locations l ON l.ZoneRowID = zr.ZoneRowID
),
OccupiedLocations AS (
    SELECT DISTINCT LocationID
    FROM Belteh.Inventory
)
SELECT
    zl.ZoneID,
    COUNT(zl.LocationID) AS TotalLocations,
    COUNT(CASE WHEN ol.LocationID IS NOT NULL THEN 1 END) AS OccupiedLocations,
    ROUND(
        CAST(COUNT(CASE WHEN ol.LocationID IS NOT NULL THEN 1 END) AS FLOAT) * 100
        / NULLIF(COUNT(zl.LocationID), 0), 2
    ) AS OccupancyPercentage
FROM ZoneLocations zl
LEFT JOIN OccupiedLocations ol ON zl.LocationID = ol.LocationID
GROUP BY zl.ZoneID;
go


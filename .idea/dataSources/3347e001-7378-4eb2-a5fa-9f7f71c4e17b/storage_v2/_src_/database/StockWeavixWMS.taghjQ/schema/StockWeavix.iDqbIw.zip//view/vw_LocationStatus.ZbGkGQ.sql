
CREATE VIEW Belteh.vw_LocationStatus AS
SELECT
  L.LocationID,
  Z.ZoneCode,
  ZR.RowNumber,
  ZS.SectionNumber,
  ZSh.ShelfLevel,
  ISNULL(SUM(I.Quantity), 0) AS TotalQuantity,
  CASE 
    WHEN ISNULL(SUM(I.Quantity), 0) = 0 THEN N'Порожня'
    ELSE N'Використовується'
  END AS ShelfStatus
FROM Belteh.Locations    AS L
JOIN Belteh.ZoneRows     AS ZR ON L.ZoneRowID   = ZR.ZoneRowID
JOIN Belteh.Zones        AS Z  ON ZR.ZoneID      = Z.ZoneID
JOIN Belteh.ZoneSections AS ZS ON L.SectionID    = ZS.SectionID
JOIN Belteh.ZoneShelves  AS ZSh ON L.ShelfID      = ZSh.ShelfID
LEFT JOIN Belteh.Inventory AS I ON L.LocationID   = I.LocationID
GROUP BY
  L.LocationID,
  Z.ZoneCode,
  ZR.RowNumber,
  ZS.SectionNumber,
  ZSh.ShelfLevel;
go


-- Модифікований тригер з логуванням
CREATE TRIGGER Belteh.trg_SyncContractPrice
ON Belteh.SupplyDetails
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @ActionType VARCHAR(10);
  IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    SET @ActionType = 'UPDATE';
  ELSE IF EXISTS (SELECT * FROM inserted)
    SET @ActionType = 'INSERT';
  ELSE
    SET @ActionType = 'DELETE';

  DECLARE @Changed TABLE (SupplyID INT PRIMARY KEY);
  INSERT INTO @Changed(SupplyID)
    SELECT SupplyID FROM inserted
    UNION
    SELECT SupplyID FROM deleted;

  -- Логування
  INSERT INTO Belteh.TriggerLog (SupplyID, ActionType)
  SELECT SupplyID, @ActionType FROM @Changed;

  UPDATE c
  SET c.ContractPrice = COALESCE(s.TotalCost, 0.00) -- Додано COALESCE для випадку, коли немає деталей
  FROM Belteh.SupplyContracts AS c
  LEFT JOIN ( -- Змінено на LEFT JOIN, щоб оновити на 0, якщо всі деталі видалені
    SELECT d.SupplyID, SUM(d.Quantity * d.UnitPrice) AS TotalCost
    FROM Belteh.SupplyDetails AS d
    JOIN @Changed AS ch ON ch.SupplyID = d.SupplyID
    GROUP BY d.SupplyID
  ) AS s ON c.SupplyID = s.SupplyID
  WHERE c.SupplyID IN (SELECT SupplyID FROM @Changed); -- Оновлюємо тільки змінені контракти
END;
go


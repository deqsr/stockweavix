
-- Створюємо новий без LocationStatusID
CREATE TRIGGER Belteh.trg_UpdateLocationStatus
ON Belteh.Inventory
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
  SET NOCOUNT ON;

  -- Отримуємо унікальні LocationID, що змінилися
  DECLARE @Changed TABLE (LocationID INT PRIMARY KEY);

  INSERT INTO @Changed(LocationID)
  SELECT DISTINCT LocationID FROM inserted
  WHERE LocationID IS NOT NULL
  UNION
  SELECT DISTINCT LocationID FROM deleted
  WHERE LocationID IS NOT NULL;

  -- Можеш тут вставити логування, наприклад:
  -- INSERT INTO Belteh.LocationChangesLog (LocationID, ChangeDate)
  -- SELECT LocationID, GETDATE() FROM @Changed;

  -- або просто залишити тригер "порожнім", якщо більше нічого не потрібно
END;
go

